from __future__ import annotations

import os
from pathlib import Path

try:
    from snapfusion.pipelines import StableDiffusionPipeline
except ImportError:
    from diffusers import StableDiffusionPipeline
from diffusers import EulerAncestralDiscreteScheduler
import torch

try:
    import torch_neuronx

    HAS_TORCH_NEURONX = True
except ImportError:
    HAS_TORCH_NEURONX = False

from diffusion_benchmarker.common import TORCH_DTYPES
from diffusion_benchmarker.loaders import register_loader
from diffusion_benchmarker.neuronx.wrappers import NeuronTextEncoder
from diffusion_benchmarker.neuronx.wrappers import NeuronUNet
from diffusion_benchmarker.neuronx.wrappers import NeuronUpcastWrapper
from diffusion_benchmarker.neuronx.wrappers import UNetWrap

os.environ["NEURON_FUSE_SOFTMAX"] = "1"


def _assert_torch_neuronx() -> None:
    if not HAS_TORCH_NEURONX:
        raise ModuleNotFoundError(
            "Package `torch-neuronx` is required to be installed to use this pipeline loader."
            "Follow instructions: https://awsdocs-neuron.readthedocs-hosted.com/en/latest/general/setup/torch-neuronx.html",
        )


@register_loader("neuronx_t2i")
class NeuronxT2ILoader:
    def __init__(
        self,
        root: str | Path,
        pretrained_model_name_or_path: str | Path,
        torch_dtype: str = "float32",
        unet_data_parallel: bool = True,
        device_ids: list[int] | None = None,
    ):
        self.root = Path(root)
        self.pretrained_model_name_or_path = pretrained_model_name_or_path
        self.torch_dtype = TORCH_DTYPES[torch_dtype]
        self.unet_data_parallel = unet_data_parallel
        self.device_ids = device_ids or [0, 1]

    def load(self) -> StableDiffusionPipeline:
        _assert_torch_neuronx()

        pipe = StableDiffusionPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            safety_checker=None,
            torch_dtype=self.torch_dtype,
        )
        pipe.scheduler = EulerAncestralDiscreteScheduler.from_config(pipe.scheduler.config)

        text_encoder_filename = self.root / "text_encoder/model.pt"
        unet_filename = self.root / "unet/model.pt"
        decoder_filename = self.root / "vae_decoder/model.pt"
        post_quant_conv_filename = self.root / "vae_post_quant_conv/model.pt"

        pipe.unet = NeuronUNet(UNetWrap(pipe.unet), dtype=self.torch_dtype)
        unetwrap = torch.jit.load(unet_filename)
        if self.unet_data_parallel:
            unetwrap = torch_neuronx.DataParallel(
                unetwrap,
                self.device_ids,
                set_dynamic_batching=False,
            )
        pipe.unet.unetwrap = unetwrap

        pipe.text_encoder = NeuronTextEncoder(pipe.text_encoder)
        pipe.text_encoder.neuron_text_encoder = torch.jit.load(text_encoder_filename)
        pipe.vae.decoder = NeuronUpcastWrapper(torch.jit.load(decoder_filename))
        pipe.vae.post_quant_conv = NeuronUpcastWrapper(torch.jit.load(post_quant_conv_filename))

        return pipe
