from __future__ import annotations

from typing import Callable
from typing import Protocol
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from diffusers import DiffusionPipeline


class Loader(Protocol):
    def load(self) -> DiffusionPipeline:
        ...


class LoaderFactory:
    def __init__(self):
        self.loaders: dict[str, Loader] = {}

    def register_loader(self, name: str) -> Callable[[type[Loader]], type[Loader]]:
        def _decorator(cls: type[Loader]) -> type[Loader]:
            if name not in self.loaders:
                self.loaders[name] = cls
            else:
                raise ValueError("There cannot be any loaders with the same name")
            return cls

        return _decorator

    def create_loader(self, name: str, *args, **kwargs) -> Loader:
        return self.loaders[name](*args, **kwargs)


_factory = LoaderFactory()

register_loader = _factory.register_loader
create_loader = _factory.create_loader
