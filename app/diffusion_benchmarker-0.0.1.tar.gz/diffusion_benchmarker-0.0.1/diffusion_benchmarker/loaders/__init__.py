from diffusion_benchmarker.loaders.loader import create_loader
from diffusion_benchmarker.loaders.loader import register_loader

from .inductor_ip2p import InductorIP2PLoader
from .inductor_t2i import InductorT2ILoader
from .neuronx_ip2p import NeuronxIP2PLoader
from .neuronx_t2i import NeuronxT2ILoader

__all__ = [
    "register_loader",
    "create_loader",
    "InductorT2ILoader",
    "NeuronxT2ILoader",
    "NeuronxIP2PLoader",
    "InductorIP2PLoader",
]
