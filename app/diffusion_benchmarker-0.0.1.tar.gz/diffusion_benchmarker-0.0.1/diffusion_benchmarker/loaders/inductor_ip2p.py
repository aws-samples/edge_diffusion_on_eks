from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

from diffusers import EulerAncestralDiscreteScheduler
from diffusers import StableDiffusionInstructPix2PixPipeline
import torch

from diffusion_benchmarker.common import TORCH_DTYPES

from .loader import register_loader


@register_loader("inductor_ip2p")
class InductorIP2PLoader:
    def __init__(
        self,
        pretrained_model_name_or_path: str | Path,
        device: torch.device | str = "cuda",
        torch_dtype: str = "bfloat16",
    ):
        self.pretrained_model_name_or_path = pretrained_model_name_or_path
        self.device = device
        self.torch_dtype = TORCH_DTYPES[torch_dtype]

    def load(self) -> StableDiffusionInstructPix2PixPipeline:
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            safety_checker=None,
            torch_dtype=self.torch_dtype,
        ).to(self.device)

        pipe.scheduler = EulerAncestralDiscreteScheduler.from_config(pipe.scheduler.config)

        pipe.unet.to(memory_format=torch.channels_last)
        pipe.vae.to(memory_format=torch.channels_last)

        pipe.unet = torch.compile(pipe.unet, fullgraph=True, mode="max-autotune")

        pipe.text_encoder = torch.compile(
            pipe.text_encoder,
            fullgraph=True,
            mode="max-autotune",
        )

        pipe.vae.decoder = torch.compile(
            pipe.vae.decoder,
            fullgraph=True,
            mode="max-autotune",
        )
        pipe.vae.post_quant_conv = torch.compile(
            pipe.vae.post_quant_conv,
            fullgraph=True,
            mode="max-autotune-no-cudagraphs",
        )

        pipe.vae.encoder = torch.compile(
            pipe.vae.encoder,
            fullgraph=True,
            mode="max-autotune",
        )
        pipe.vae.quant_conv = torch.compile(
            pipe.vae.quant_conv,
            fullgraph=True,
            mode="max-autotune-no-cudagraphs",
        )

        return pipe
