from __future__ import annotations

import copy
import os
from pathlib import Path

from diffusers import StableDiffusionInstructPix2PixPipeline
from diffusers.models.attention_processor import Attention
import torch

try:
    import torch_neuronx

    HAS_TORCH_NEURONX = True
except ImportError:
    HAS_TORCH_NEURONX = False

from diffusion_benchmarker.common import TORCH_DTYPES
from diffusion_benchmarker.exporters import register_exporter
from diffusion_benchmarker.neuronx.decorators import ensure_text_encoder_forward_neuron_compilable
from diffusion_benchmarker.neuronx.decorators import ensure_unet_forward_neuron_compilable
from diffusion_benchmarker.neuronx.ops import get_attention_scores
from diffusion_benchmarker.neuronx.wrappers import NeuronTextEncoder
from diffusion_benchmarker.neuronx.wrappers import NeuronUNet
from diffusion_benchmarker.neuronx.wrappers import UNetWrap

os.environ["NEURON_FUSE_SOFTMAX"] = "1"

NEURON_COMPILER_TYPE_CASTING_CONFIG = [
    # "--auto-cast=matmult",
    # "--auto-cast-type=bf16",
]

NEURON_COMPILER_CLI_ARGS = [
    "--target=inf2",
    "--enable-fast-loading-neuron-binaries",
    *NEURON_COMPILER_TYPE_CASTING_CONFIG,
]


def _assert_torch_neuronx() -> None:
    if not HAS_TORCH_NEURONX:
        raise ModuleNotFoundError(
            "Package `torch-neuronx` is required to be installed to use this pipeline loader."
            "Follow instructions: https://awsdocs-neuron.readthedocs-hosted.com/en/latest/general/setup/torch-neuronx.html",
        )


@register_exporter("neuronx_ip2p_v2")
class NeuronxIP2PExporterV2:
    def __init__(
        self,
        output_dir: str | Path,
        pretrained_model_name_or_path: str | Path,
        height: int = 512,
        width: int = 512,
        batch_size: int = 1,
        torch_dtype: str = "float32",
        unet_batch_size: int | None = None,
    ) -> None:
        self.torch_dtype = TORCH_DTYPES[torch_dtype]
        self.output_dir = Path(output_dir)
        self.pretrained_model_name_or_path = pretrained_model_name_or_path
        self.height = height
        self.width = width
        self.batch_size = batch_size
        self.unet_batch_size = unet_batch_size if unet_batch_size is not None else batch_size

    def trace_text_encoder(self) -> None:
        compiler_workdir = self.output_dir / "text_encoder"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=self.torch_dtype,
        )

        text_encoder = copy.deepcopy(pipe.text_encoder)
        text_encoder = ensure_text_encoder_forward_neuron_compilable(text_encoder)

        vocab_size = pipe.tokenizer.vocab_size
        model_max_length = pipe.tokenizer.model_max_length

        del pipe

        # Execution time: ~1-2mins
        example_input_ids = torch.randint(0, vocab_size, (self.batch_size, model_max_length), dtype=torch.int64)

        with torch.no_grad():
            text_encoder_neuron = torch_neuronx.trace(
                text_encoder,
                example_input_ids,
                compiler_workdir=compiler_workdir,
                compiler_args=[*NEURON_COMPILER_CLI_ARGS, f"--logfile={compiler_workdir/ 'log-neuron-cc.txt'}"],
            )

        # Free up memory
        del example_input_ids, text_encoder

        torch_neuronx.async_load(text_encoder_neuron)
        torch_neuronx.lazy_load(text_encoder_neuron)

        torch.jit.save(text_encoder_neuron, compiler_workdir / "text_encoder.pt")

        # Free up memory
        del text_encoder_neuron

    def trace_unet(self) -> None:
        compiler_workdir = self.output_dir / "unet"
        compiler_workdir.mkdir(exist_ok=True, parents=True)
        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=self.torch_dtype,
        )

        unet = copy.deepcopy(pipe.unet)
        unet = ensure_unet_forward_neuron_compilable(unet)

        unet_in_channels = pipe.unet.config.in_channels
        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)
        encoder_projection_dim = pipe.text_encoder.config.hidden_size
        model_max_length = pipe.tokenizer.model_max_length

        Attention.get_attention_scores = get_attention_scores

        del pipe

        # Execution time: ~10mins
        example_input_sample = torch.randn(
            (
                self.unet_batch_size,
                unet_in_channels,
                self.height // vae_scaling_factor,
                self.width // vae_scaling_factor,
            ),
            dtype=self.torch_dtype,
        )
        example_timestep = torch.randint(0, 1000, (self.unet_batch_size,), dtype=self.torch_dtype)
        example_encoder_hidden_states = torch.randn(
            (self.unet_batch_size, model_max_length, encoder_projection_dim),
            dtype=self.torch_dtype,
        )
        example_inputs = (example_input_sample, example_timestep, example_encoder_hidden_states)

        with torch.no_grad():
            unet_neuron = torch_neuronx.trace(
                unet,
                example_inputs,
                compiler_workdir=compiler_workdir,
                compiler_args=[
                    *NEURON_COMPILER_CLI_ARGS,
                    f"--logfile={compiler_workdir / 'log-neuron-cc.txt'}",
                    "--model-type=unet-inference",
                ],
            )

        # Free up memory
        del example_input_sample, example_timestep, example_encoder_hidden_states, example_inputs, unet

        torch_neuronx.async_load(unet_neuron)
        torch_neuronx.lazy_load(unet_neuron)

        torch.jit.save(unet_neuron, compiler_workdir / "unet.pt")

        # Free up memory
        del unet_neuron

    def trace_vae(self) -> None:
        compiler_workdir = self.output_dir / "vae"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=self.torch_dtype,
        )

        vae_post_quant_conv = copy.deepcopy(pipe.vae.post_quant_conv)
        vae_decoder = copy.deepcopy(pipe.vae.decoder)
        vae_quant_conv = copy.deepcopy(pipe.vae.quant_conv)
        vae_encoder = copy.deepcopy(pipe.vae.encoder)

        latent_channels = pipe.vae.config.latent_channels
        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)

        del pipe

        # Execution time: ~7-8mins
        example_latent_sample = torch.randn(
            (self.batch_size, latent_channels, self.height // vae_scaling_factor, self.width // vae_scaling_factor),
            dtype=torch.float32,
        )
        example_quant_sample = torch.randn(
            (self.batch_size, latent_channels * 2, self.height // vae_scaling_factor, self.width // vae_scaling_factor),
            dtype=torch.float32,
        )
        example_image_sample = torch.randn([1, 3, self.height, self.width])

        with torch.no_grad():
            vae_post_quant_conv_compiler_dir = compiler_workdir / "post_quant_conv"
            vae_post_quant_conv_neuron = torch_neuronx.trace(
                vae_post_quant_conv,
                example_latent_sample,
                compiler_workdir=vae_post_quant_conv_compiler_dir,
                compiler_args=[
                    *NEURON_COMPILER_CLI_ARGS,
                    f"--logfile={vae_post_quant_conv_compiler_dir / 'log-neuron-cc.txt'}",
                ],
            )

            vae_decoder_compiler_dir = compiler_workdir / "decoder"
            vae_decoder_neuron = torch_neuronx.trace(
                vae_decoder,
                example_latent_sample,
                compiler_workdir=vae_decoder_compiler_dir / "decoder",
                compiler_args=[
                    *NEURON_COMPILER_CLI_ARGS,
                    f"--logfile={vae_decoder_compiler_dir / 'log-neuron-cc.txt'}",
                ],
            )

            vae_quant_conv_compiler_dir = compiler_workdir / "quant_conv"
            vae_quant_conv_neuron = torch_neuronx.trace(
                vae_quant_conv,
                example_quant_sample,
                compiler_workdir=vae_quant_conv_compiler_dir,
                compiler_args=[
                    *NEURON_COMPILER_CLI_ARGS,
                    f"--logfile={vae_quant_conv_compiler_dir / 'log-neuron-cc.txt'}",
                ],
            )

            vae_encoder_compiler_dir = compiler_workdir / "encoder"
            vae_encoder_neuron = torch_neuronx.trace(
                vae_encoder,
                example_image_sample,
                compiler_workdir=vae_encoder_compiler_dir / "encoder",
                compiler_args=[
                    *NEURON_COMPILER_CLI_ARGS,
                    f"--logfile={vae_encoder_compiler_dir / 'log-neuron-cc.txt'}",
                ],
            )

        # Free up memory
        del vae_post_quant_conv, vae_decoder, vae_encoder, vae_quant_conv, example_latent_sample, example_quant_sample

        for neuron_model, file_name in zip(
            (vae_post_quant_conv_neuron, vae_quant_conv_neuron, vae_decoder_neuron, vae_encoder_neuron),
            ("vae_post_quant_conv.pt", "vae_quant_conv_neuron.pt", "vae_decoder.pt", "vae_encoder.pt"),
        ):
            torch_neuronx.async_load(neuron_model)
            torch_neuronx.lazy_load(neuron_model)
            torch.jit.save(neuron_model, compiler_workdir / file_name)

        # Free up memory
        del vae_post_quant_conv_neuron, vae_decoder_neuron, vae_encoder_neuron, vae_quant_conv_neuron

    def export(self) -> None:
        _assert_torch_neuronx()

        self.trace_text_encoder()
        self.trace_unet()
        self.trace_vae()


@register_exporter("neuronx_ip2p")
class NeuronxIP2PExporter:
    def __init__(
        self,
        output_dir: str | Path,
        pretrained_model_name_or_path: str | Path,
        height: int = 512,
        width: int = 512,
        batch_size: int = 1,
        torch_dtype: str = "float32",
        unet_batch_size: int | None = None,
    ) -> None:
        self.torch_dtype = TORCH_DTYPES[torch_dtype]
        self.output_dir = Path(output_dir)
        self.pretrained_model_name_or_path = pretrained_model_name_or_path
        self.height = height
        self.width = width
        self.batch_size = batch_size
        self.unet_batch_size = unet_batch_size if unet_batch_size is not None else batch_size

    def trace_text_encoder(self) -> None:
        compiler_workdir = self.output_dir / "text_encoder"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=self.torch_dtype,
        )

        text_encoder = copy.deepcopy(pipe.text_encoder)
        text_encoder = NeuronTextEncoder(text_encoder)

        vocab_size = pipe.tokenizer.vocab_size
        model_max_length = pipe.tokenizer.model_max_length

        del pipe

        # Execution time: ~1-2mins
        example_input_ids = torch.randint(0, vocab_size, (self.batch_size, model_max_length), dtype=torch.int64)

        with torch.no_grad():
            text_encoder_neuron = torch_neuronx.trace(
                text_encoder.neuron_text_encoder,
                example_input_ids,
                compiler_workdir=compiler_workdir,
                compiler_args=["--enable-fast-loading-neuron-binaries"],
            )

        # Free up memory
        del example_input_ids, text_encoder

        torch_neuronx.async_load(text_encoder_neuron)
        torch_neuronx.lazy_load(text_encoder_neuron)

        torch.jit.save(text_encoder_neuron, compiler_workdir / "model.pt")

        # Free up memory
        del text_encoder_neuron

    def trace_unet(self) -> None:
        compiler_workdir = self.output_dir / "unet"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=self.torch_dtype,
        )

        # Replace original cross-attention module with custom cross-attention module for better performance
        Attention.get_attention_scores = get_attention_scores

        # Apply double wrapper to deal with custom return type
        pipe.unet = NeuronUNet(UNetWrap(pipe.unet), dtype=self.torch_dtype)

        # Only keep the model being compiled in RAM to minimze memory pressure
        unet = copy.deepcopy(pipe.unet.unetwrap)

        unet_in_channels = pipe.unet.config.in_channels
        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)
        encoder_projection_dim = pipe.text_encoder.config.hidden_size
        model_max_length = pipe.tokenizer.model_max_length

        del pipe

        example_input_sample = torch.randn(
            (
                self.unet_batch_size,
                unet_in_channels,
                self.height // vae_scaling_factor,
                self.width // vae_scaling_factor,
            ),
            dtype=self.torch_dtype,
        )
        example_timestep = torch.randint(0, 1000, (self.unet_batch_size,), dtype=self.torch_dtype)
        example_encoder_hidden_states = torch.randn(
            (self.unet_batch_size, model_max_length, encoder_projection_dim),
            dtype=self.torch_dtype,
        )
        example_inputs = (example_input_sample, example_timestep, example_encoder_hidden_states)

        with torch.no_grad():
            unet_neuron = torch_neuronx.trace(
                unet,
                example_inputs,
                compiler_workdir=compiler_workdir,
                compiler_args=["--model-type=unet-inference", "--enable-fast-loading-neuron-binaries"],
            )
        del example_input_sample, example_timestep, example_encoder_hidden_states, example_inputs, unet

        # Enable asynchronous and lazy loading to speed up model load
        torch_neuronx.async_load(unet_neuron)
        torch_neuronx.lazy_load(unet_neuron)

        # save compiled unet
        unet_filename = compiler_workdir / "model.pt"
        torch.jit.save(unet_neuron, unet_filename)

        # delete unused objects
        del unet_neuron

    def trace_vae_decoder(self) -> None:
        compiler_workdir = self.output_dir / "vae_decoder"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=torch.float32,
        )

        vae_decoder = copy.deepcopy(pipe.vae.decoder)

        latent_channels = pipe.vae.config.latent_channels
        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)

        del pipe

        # Execution time: ~7-8mins
        example_latent_sample = torch.randn(
            (self.batch_size, latent_channels, self.height // vae_scaling_factor, self.width // vae_scaling_factor),
            dtype=torch.float32,
        )

        with torch.no_grad():
            vae_decoder_neuron = torch_neuronx.trace(
                vae_decoder,
                example_latent_sample,
                compiler_workdir=compiler_workdir,
                compiler_args=["--enable-fast-loading-neuron-binaries"],
            )

        # Free up memory
        del vae_decoder, example_latent_sample

        torch_neuronx.lazy_load(vae_decoder_neuron)
        torch.jit.save(vae_decoder_neuron, compiler_workdir / "model.pt")

        # Free up memory
        del vae_decoder_neuron

    def trace_vae_encoder(self) -> None:
        compiler_workdir = self.output_dir / "vae_encoder"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=torch.float32,
        )

        vae_encoder = copy.deepcopy(pipe.vae.encoder)

        del pipe

        # Execution time: ~7-8mins
        example_image_sample = torch.randn(
            (self.batch_size, 3, self.height, self.width),
            dtype=torch.float32,
        )

        with torch.no_grad():
            vae_encoder_neuron = torch_neuronx.trace(
                vae_encoder,
                example_image_sample,
                compiler_workdir=compiler_workdir,
                compiler_args=["--enable-fast-loading-neuron-binaries"],
            )

        # Free up memory
        del vae_encoder, example_image_sample

        torch_neuronx.lazy_load(vae_encoder_neuron)
        torch.jit.save(vae_encoder_neuron, compiler_workdir / "model.pt")

        # Free up memory
        del vae_encoder_neuron

    def trace_post_quant_conv(self) -> None:
        compiler_workdir = self.output_dir / "vae_post_quant_conv"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=torch.float32,
        )

        post_quant_conv = copy.deepcopy(pipe.vae.post_quant_conv)

        latent_channels = pipe.vae.config.latent_channels
        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)

        del pipe

        # Execution time: ~7-8mins
        example_latent_sample = torch.randn(
            (self.batch_size, latent_channels, self.height // vae_scaling_factor, self.width // vae_scaling_factor),
            dtype=torch.float32,
        )

        with torch.no_grad():
            post_quant_conv_neuron = torch_neuronx.trace(
                post_quant_conv,
                example_latent_sample,
                compiler_workdir=compiler_workdir,
                compiler_args=["--enable-fast-loading-neuron-binaries"],
            )

        # Free up memory
        del post_quant_conv, example_latent_sample

        torch_neuronx.lazy_load(post_quant_conv_neuron)
        torch.jit.save(post_quant_conv_neuron, compiler_workdir / "model.pt")

        # Free up memory
        del post_quant_conv_neuron

    def trace_quant_conv(self) -> None:
        compiler_workdir = self.output_dir / "vae_quant_conv"
        compiler_workdir.mkdir(exist_ok=True, parents=True)

        # To minimze memory pressure, you only keep the model being compiled in RAM
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            self.pretrained_model_name_or_path,
            torch_dtype=torch.float32,
        )

        quant_conv = copy.deepcopy(pipe.vae.quant_conv)

        vae_scaling_factor = 2 ** (len(pipe.vae.config.block_out_channels) - 1)
        latent_channels = pipe.vae.config.latent_channels

        del pipe

        # Execution time: ~7-8mins
        example_latent_sample = torch.randn(
            (self.batch_size, latent_channels * 2, self.height // vae_scaling_factor, self.width // vae_scaling_factor),
            dtype=torch.float32,
        )

        with torch.no_grad():
            quant_conv_neuron = torch_neuronx.trace(
                quant_conv,
                example_latent_sample,
                compiler_workdir=compiler_workdir,
                compiler_args=["--enable-fast-loading-neuron-binaries"],
            )

        # Free up memory
        del quant_conv, example_latent_sample

        torch_neuronx.lazy_load(quant_conv_neuron)
        torch.jit.save(quant_conv_neuron, compiler_workdir / "model.pt")

        # Free up memory
        del quant_conv_neuron

    def export(self) -> None:
        _assert_torch_neuronx()

        self.trace_text_encoder()
        self.trace_unet()
        self.trace_vae_decoder()
        self.trace_vae_encoder()
        self.trace_quant_conv()
        self.trace_post_quant_conv()
