from __future__ import annotations

from typing import Callable
from typing import Protocol


class Exporter(Protocol):
    def export(self) -> None:
        ...


class ExporterFactory:
    def __init__(self):
        self.exporters: dict[str, Exporter] = {}

    def register_exporter(self, name: str) -> Callable[[type[Exporter]], type[Exporter]]:
        def _decorator(cls: type[Exporter]) -> type[Exporter]:
            if name not in self.exporters:
                self.exporters[name] = cls
            else:
                raise ValueError("There cannot be any loaders with the same name")
            return cls

        return _decorator

    def create_exporter(self, name: str, *args, **kwargs) -> Exporter:
        return self.exporters[name](*args, **kwargs)


_factory = ExporterFactory()

register_exporter = _factory.register_exporter
create_exporter = _factory.create_exporter
