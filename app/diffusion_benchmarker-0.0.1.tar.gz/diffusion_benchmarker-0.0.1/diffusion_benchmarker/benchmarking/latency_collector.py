import time

import numpy as np


class LatencyCollector:
    def __init__(self):
        self.start = float("-inf")
        self.latency_list = []

    def pre_hook(self) -> None:
        self.start = time.time()

    def hook(self) -> None:
        self.latency_list.append(time.time() - self.start)

    def percentile(self, percent: int) -> float:
        return np.percentile(self.latency_list, percent)
