from abc import ABCMeta
from abc import abstractmethod
import time

import numpy as np
import torch
from typing_extensions import Self


class AbstractLatencyCollector(metaclass=ABCMeta):

    @abstractmethod
    def pre_hook(self, *_args, **_kwargs) -> None: ...

    @abstractmethod
    def hook(self, *_args, **_kwargs) -> None: ...

    @abstractmethod
    def percentile(self, percent: int) -> float: ...

    def __enter__(self) -> Self:
        self.pre_hook()
        return self

    def __exit__(self, _type, _value, _traceback):
        self.hook()


class LatencyCollector(AbstractLatencyCollector):
    def __init__(self):
        self.start = float("-inf")
        self.latency_list = []

    def pre_hook(self, *_args, **_kwargs) -> None:
        self.start = time.time()

    def hook(self, *_args, **_kwargs) -> None:
        self.latency_list.append(time.time() - self.start)

    def percentile(self, percent: int) -> float:
        return np.percentile(self.latency_list, percent)


class CudaSynchronizedLatencyCollector(AbstractLatencyCollector):
    def __init__(self):
        self.start = float("-inf")
        self.latency_list = []

    def pre_hook(self, *_args, **_kwargs) -> None:
        torch.cuda.synchronize()
        self.start = time.time()

    def hook(self, *_args, **_kwargs) -> None:
        torch.cuda.synchronize()
        self.latency_list.append(time.time() - self.start)

    def percentile(self, percent: int) -> float:
        return np.percentile(self.latency_list, percent)


def print_report(report_name: str, latency_collector: AbstractLatencyCollector) -> None:
    p0_latency_ms = latency_collector.percentile(0) * 1000
    p50_latency_ms = latency_collector.percentile(50) * 1000
    p90_latency_ms = latency_collector.percentile(90) * 1000
    p95_latency_ms = latency_collector.percentile(95) * 1000
    p99_latency_ms = latency_collector.percentile(99) * 1000
    p100_latency_ms = latency_collector.percentile(100) * 1000

    report_dict = {}
    report_dict["Latency P0"] = f"{p0_latency_ms:.1f}"
    report_dict["Latency P50"] = f"{p50_latency_ms:.1f}"
    report_dict["Latency P90"] = f"{p90_latency_ms:.1f}"
    report_dict["Latency P95"] = f"{p95_latency_ms:.1f}"
    report_dict["Latency P99"] = f"{p99_latency_ms:.1f}"
    report_dict["Latency P100"] = f"{p100_latency_ms:.1f}"

    report = f"RESULT FOR {report_name}:"
    for key, value in report_dict.items():
        report += f" {key}={value}"
    print(report)
