from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from diffusers import DiffusionPipeline

from diffusion_benchmarker.benchmarking.latency_collector import LatencyCollector


def benchmark(
    test_name: str,
    n_runs: int,
    pipe: DiffusionPipeline,
    *pipe_args,
    **pipe_kwargs,
):
    # warm-up
    for _ in range(3):
        _ = pipe(*pipe_args, **pipe_kwargs)

    latency_collector = LatencyCollector()

    for _ in range(n_runs):
        latency_collector.pre_hook()
        _ = pipe(*pipe_args, **pipe_kwargs)
        latency_collector.hook()

    p0_latency_ms = latency_collector.percentile(0) * 1000
    p50_latency_ms = latency_collector.percentile(50) * 1000
    p90_latency_ms = latency_collector.percentile(90) * 1000
    p95_latency_ms = latency_collector.percentile(95) * 1000
    p99_latency_ms = latency_collector.percentile(99) * 1000
    p100_latency_ms = latency_collector.percentile(100) * 1000

    report_dict = {}
    report_dict["Latency P0"] = f"{p0_latency_ms:.1f}"
    report_dict["Latency P50"] = f"{p50_latency_ms:.1f}"
    report_dict["Latency P90"] = f"{p90_latency_ms:.1f}"
    report_dict["Latency P95"] = f"{p95_latency_ms:.1f}"
    report_dict["Latency P99"] = f"{p99_latency_ms:.1f}"
    report_dict["Latency P100"] = f"{p100_latency_ms:.1f}"

    report = f"RESULT FOR {test_name}:"
    for key, value in report_dict.items():
        report += f" {key}={value}"
    print(report)
