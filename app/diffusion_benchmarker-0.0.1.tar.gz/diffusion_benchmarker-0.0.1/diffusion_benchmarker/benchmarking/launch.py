from __future__ import annotations

from contextlib import nullcontext
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from diffusers import DiffusionPipeline

    from diffusion_benchmarker.benchmarking.latency_collector import AbstractLatencyCollector


def benchmark(
    n_runs: int,
    pipe: DiffusionPipeline,
    latency_collector: AbstractLatencyCollector | None = None,
    pipe_args: tuple | None = None,
    pipe_kwargs: dict | None = None,
):
    pipe_args = pipe_args or ()
    pipe_kwargs = pipe_kwargs or {}
    # warm-up
    for _ in range(3):
        _ = pipe(*pipe_args, **pipe_kwargs)

    context = latency_collector or nullcontext()

    for _ in range(n_runs):
        with context:
            _ = pipe(*pipe_args, **pipe_kwargs)
