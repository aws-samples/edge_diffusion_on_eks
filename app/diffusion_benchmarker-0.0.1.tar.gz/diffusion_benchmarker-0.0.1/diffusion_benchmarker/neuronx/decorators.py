# ruff: noqa: ARG001
from __future__ import annotations

from typing import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    try:
        import torch_neuronx

        HAS_TORCH_NEURONX = True
    except ImportError:
        HAS_TORCH_NEURONX = False
    from diffusers.models.unet_2d_condition import UNet2DConditionModel
    import torch
    from transformers.models.clip.modeling_clip import CLIPTextModel
    from transformers.models.clip.modeling_clip import CLIPVisionModel

from diffusers.models.unet_2d_condition import UNet2DConditionModel
from diffusers.models.unet_2d_condition import UNet2DConditionOutput
import torch
from transformers.modeling_outputs import BaseModelOutputWithPooling


def ensure_unet_forward_neuron_compilable(model: UNet2DConditionModel) -> UNet2DConditionModel:
    def decorate_forward_method(f: Callable) -> Callable:
        def decorated_forward_method(*args, **kwargs) -> torch.Tensor:
            kwargs.update({"return_dict": False})
            (output_sample,) = f(*args, **kwargs)
            return output_sample

        return decorated_forward_method

    model.forward = decorate_forward_method(model.forward)
    return model


def ensure_text_encoder_forward_neuron_compilable(model: CLIPTextModel) -> CLIPTextModel:
    def decorate_forward_method(f: Callable) -> Callable:
        def decorated_forward_method(*args, **kwargs) -> tuple[torch.Tensor]:
            kwargs.update({"return_dict": False})
            return f(*args, **kwargs)

        return decorated_forward_method

    model.forward = decorate_forward_method(model.forward)
    return model


def text_encoder_runtime_decorator_factory(neuron_model: torch.jit.ScriptModule) -> torch.jit.ScriptModule:
    def text_encoder_decorator(model: CLIPTextModel) -> CLIPTextModel:
        def neuron_forward_method(*args, **kwargs) -> BaseModelOutputWithPooling:
            (
                input_ids,
                *_,
            ) = args  # Ensures that only a single (the first) arg is supplied to the compiled model, kwargs are discarded
            last_hidden_state, pooler_output = neuron_model(input_ids)
            return BaseModelOutputWithPooling(last_hidden_state=last_hidden_state, pooler_output=pooler_output)

        model.forward = neuron_forward_method
        return model

    return text_encoder_decorator


def unet_runtime_decorator_factory(
    neuron_model: torch_neuronx.xla_impl.data_parallel.DataParallel,
    dtype: torch.dtype | str,
) -> torch_neuronx.xla_impl.data_parallel.DataParallel:
    def unet_decorator(model: UNet2DConditionModel) -> UNet2DConditionModel:
        def neuron_forward_method(*args, **kwargs) -> UNet2DConditionOutput:
            sample, timestep, *_ = args
            dim_0 = sample.shape[0]
            if isinstance(timestep, (int, float)):
                timestep = torch.Tensor([timestep] * dim_0).to(dtype=dtype)
            else:
                timestep = timestep.to(dtype=dtype).repeat(dim_0)
            encoder_hidden_states = kwargs["encoder_hidden_states"]
            output_sample = neuron_model(sample, timestep, encoder_hidden_states)
            return UNet2DConditionOutput(sample=output_sample)

        model.forward = neuron_forward_method
        return model

    return unet_decorator


def vision_model_runtime_decorator_factory(neuron_model: torch.jit.ScriptModule) -> torch.jit.ScriptModule:
    def vision_model_checker_decorator(model: CLIPVisionModel) -> CLIPVisionModel:
        def neuron_forward_method(*args, **kwargs) -> BaseModelOutputWithPooling:
            pixel_values, *_ = args  # Ensures that only a single (the first) arg is supplied to the compiled model
            last_hidden_state, pooler_output = neuron_model(pixel_values)
            return BaseModelOutputWithPooling(last_hidden_state=last_hidden_state, pooler_output=pooler_output)

        model.forward = neuron_forward_method
        return model

    return vision_model_checker_decorator
