# ruff: noqa: ARG001
from __future__ import annotations

import torch


def get_attention_scores(
    self,
    query: torch.Tensor,
    key: torch.Tensor,
    attention_mask: torch.Tensor | None = None,
) -> torch.Tensor:
    dtype = query.dtype

    if self.upcast_attention:
        query = query.float()
        key = key.float()

    attention_scores = self.scale * torch.bmm(query, key.transpose(-1, -2))
    # output = torch.bmm(input_1, input_2) where input_1 of shape (b, n, m), input_2 of shape (b, m, p) and output of shape (b, n, p)
    # Attention: query of shape (b, model_length, d_q), key of shape (b, model_length, d_k), assuming d_q=d_k, expected
    # bmm(query, key) = attention tensor of shape (b, model_length, model_length) -> Key tensor dims needs to be rearranged into
    # (b, d_k, model_length), i.e. swapping dim -1 & -2, i.e. key.transpose(-1, -2)

    if self.upcast_softmax:
        attention_scores = attention_scores.float()

    attention_probs = torch.nn.functional.softmax(attention_scores, dim=-1)
    del attention_scores
    return attention_probs.to(dtype)
