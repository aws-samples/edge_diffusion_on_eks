# ruff: noqa : ARG002
from __future__ import annotations

from typing import Any

from diffusers.models.unet_2d_condition import UNet2DConditionOutput
import torch
from torch import nn


class UNetWrap(nn.Module):
    def __init__(self, unet: nn.Module):
        super().__init__()
        self.unet = unet

    def forward(
        self,
        sample: torch.Tensor,
        timestep: torch.Tensor | float,
        encoder_hidden_states: torch.Tensor,
        cross_attention_kwargs: dict[str, Any] | None = None,
    ):
        return self.unet(
            sample,
            timestep,
            encoder_hidden_states,
            return_dict=False,
        )


class NeuronUNet(nn.Module):
    def __init__(self, unetwrap, dtype):
        super().__init__()
        self.unetwrap = unetwrap
        self.config = unetwrap.unet.config
        self.in_channels = unetwrap.unet.in_channels
        self.device = unetwrap.unet.device
        self.dtype = dtype

    def forward(
        self,
        sample: torch.Tensor,
        timestep: torch.Tensor | float,
        encoder_hidden_states: torch.Tensor,
        cross_attention_kwargs: dict[str, Any] | None = None,
        return_dict: bool = False,
        timestep_cond: torch.Tensor | None = None,
        added_cond_kwargs: dict[str, torch.Tensor] | None = None,
    ):
        sample = self.unetwrap(
            sample,
            timestep.to(dtype=self.dtype).expand((sample.shape[0],)),
            encoder_hidden_states,
        )[0]
        return UNet2DConditionOutput(sample=sample)


class NeuronTextEncoder(nn.Module):
    def __init__(self, text_encoder):
        super().__init__()
        self.neuron_text_encoder = text_encoder
        self.config = text_encoder.config
        self.dtype = text_encoder.dtype
        self.device = text_encoder.device

    def forward(self, emb: torch.Tensor, attention_mask: torch.Tensor | None = None):
        return [self.neuron_text_encoder(emb)["last_hidden_state"]]


class NeuronUpcastWrapper(nn.Module):
    def __init__(self, wrapped: nn.Module):
        super().__init__()
        self.network = wrapped

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x.float())


class NeuronOutputCastWrapper(nn.Module):
    def __init__(self, wrapped: nn.Module, target_dtype: torch.dtype | str):
        super().__init__()
        self.network = wrapped
        self.target_dtype = target_dtype

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.network(x).to(dtype=self.target_dtype)
