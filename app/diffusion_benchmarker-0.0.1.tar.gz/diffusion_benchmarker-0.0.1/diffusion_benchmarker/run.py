from __future__ import annotations

from typing import Any

import click
from omegaconf import OmegaConf

from diffusion_benchmarker.benchmarking import benchmark
from diffusion_benchmarker.loaders import create_loader


@click.group
def run():
    ...


@run.command("t2i")
@click.option("--test_name", default="text-to-image")
@click.option("--iterations", default=20)
@click.option("--prompt", default="a corgie in a space suit.")
@click.option("--num_inference_steps", default=20)
@click.option("--height", default=512)
@click.option("--width", default=512)
@click.option("--pipeline", type=str)
@click.argument("loader_args_list", nargs=-1, type=click.UNPROCESSED)
def run_t2i(
    test_name: str,
    iterations: int,
    prompt: str,
    num_inference_steps: int,
    height: int,
    width: int,
    pipeline: str,
    loader_args_list: list[str],
):
    loader_args: dict[str, Any] = OmegaConf.to_container(OmegaConf.from_cli(loader_args_list))

    pipeline_loader = create_loader(pipeline, **loader_args)

    benchmark(
        test_name,
        iterations,
        pipeline_loader.load(),
        prompt=prompt,
        height=height,
        width=width,
        num_inference_steps=num_inference_steps,
    )


if __name__ == "__main__":
    run()
