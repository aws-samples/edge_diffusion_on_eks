from __future__ import annotations

from pathlib import Path
from typing import Any

import click
from omegaconf import OmegaConf
from PIL import Image

from diffusion_benchmarker.benchmarking import benchmark
from diffusion_benchmarker.benchmarking.latency_collector import LatencyCollector
from diffusion_benchmarker.benchmarking.latency_collector import print_report
from diffusion_benchmarker.loaders import create_loader


@click.group
def run(): ...


@run.command("t2i")
@click.option("--test_name", default="text-to-image")
@click.option("--iterations", default=20)
@click.option("--prompt", default="a corgie in a space suit.")
@click.option("--num_inference_steps", default=20)
@click.option("--batch_size", default=1)
@click.option("--height", default=512)
@click.option("--width", default=512)
@click.option("--pipeline", type=str)
@click.argument("loader_args_list", nargs=-1, type=click.UNPROCESSED)
def run_t2i(
    test_name: str,
    iterations: int,
    prompt: str,
    num_inference_steps: int,
    batch_size: int,
    height: int,
    width: int,
    pipeline: str,
    loader_args_list: list[str],
):
    loader_args: dict[str, Any] = OmegaConf.to_container(OmegaConf.from_cli(loader_args_list))

    pipeline_loader = create_loader(pipeline, **loader_args)

    latency_collector = LatencyCollector()
    benchmark(
        iterations,
        pipeline_loader.load(),
        latency_collector=latency_collector,
        pipe_kwargs={
            "prompt": [prompt] * batch_size,
            "height": height,
            "width": width,
            "num_inference_steps": num_inference_steps,
        },
    )
    print_report(test_name, latency_collector)


@run.command("ip2p")
@click.option("--test_name", default="instruct-pix2pix")
@click.option("--iterations", default=20)
@click.option("--prompt", default="a corgie in a space suit.")
@click.option("--num_inference_steps", default=20)
@click.option("--batch_size", default=1)
@click.option("--height", default=512)
@click.option("--width", default=512)
@click.option("--pipeline", type=str)
@click.argument("loader_args_list", nargs=-1, type=click.UNPROCESSED)
def run_ip2p(
    test_name: str,
    iterations: int,
    prompt: str,
    num_inference_steps: int,
    batch_size: int,
    height: int,
    width: int,
    pipeline: str,
    loader_args_list: list[str],
):
    loader_args: dict[str, Any] = OmegaConf.to_container(OmegaConf.from_cli(loader_args_list))

    pipeline_loader = create_loader(pipeline, **loader_args)

    test_image = Image.open(Path(__file__).parent / "assets" / "input.png").convert("RGB").resize((width, height))

    latency_collector = LatencyCollector()
    benchmark(
        iterations,
        pipeline_loader.load(),
        latency_collector=latency_collector,
        pipe_kwargs={
            "prompt": [prompt] * batch_size,
            "image": [test_image] * batch_size,
            "height": height,
            "width": width,
            "num_inference_steps": num_inference_steps,
        },
    )
    print_report(test_name, latency_collector)


if __name__ == "__main__":
    run()
