from diffusion_benchmarker.exporters import create_exporter

if __name__ == "__main__":
    exporter = create_exporter(
        "neuronx_t2i",
        output_dir="/tmp/vae_test",  # noqa: S108
        pretrained_model_name_or_path="runwayml/stable-diffusion-v1-5",
        height=512,
        width=512,
        batch_size=2,
    )
    exporter.trace_vae_decoder()
