from diffusion_benchmarker.benchmarking.latency_collector import LatencyCollector
from diffusion_benchmarker.benchmarking.latency_collector import print_report
from diffusion_benchmarker.loaders import create_loader

if __name__ == "__main__":
    loader = create_loader(
        "neuronx_t2i",
        torch_dtype="bfloat16",
        root="sd2_compile_dir_512",
        pretrained_model_name_or_path="stabilityai/stable-diffusion-2-1",
    )
    pipe = loader.load()

    # warm-up
    for _ in range(3):
        pipe("a corgie flying over London", height=512, width=512, num_inference_steps=20)

    unet_latency_collector = LatencyCollector()
    pipe.unet.register_forward_pre_hook(unet_latency_collector.pre_hook)
    pipe.unet.register_forward_hook(unet_latency_collector.hook)

    text_encoder_latency_collector = LatencyCollector()
    pipe.text_encoder.register_forward_pre_hook(text_encoder_latency_collector.pre_hook)
    pipe.text_encoder.register_forward_hook(text_encoder_latency_collector.hook)

    vae_decoder_latency_collector = LatencyCollector()
    pipe.vae.decoder.register_forward_pre_hook(vae_decoder_latency_collector.pre_hook)
    pipe.vae.decoder.register_forward_hook(vae_decoder_latency_collector.hook)

    for _ in range(20):
        pipe("a corgie flying over London", height=512, width=512, num_inference_steps=20)

    print_report("unet", unet_latency_collector)
    print_report("vae", vae_decoder_latency_collector)
    print_report("te", text_encoder_latency_collector)
